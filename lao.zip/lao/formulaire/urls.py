from django.urls import path
from . import views

urlpatterns = [
	path('formulaire1/', views.formulaire1),
	path('formulaire2/<str:answers1>', views.formulaire2),
	path('formulaire3/<str:answers2>', views.formulaire3),
]