from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.shortcuts import redirect
from django.core.files import File
from .forms import Formulaire1, Formulaire2, Formulaire3
from lao_model import views

def formulaire1(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = Formulaire1(request.POST)
        # check whether it's valid:
        if form.is_valid():
            answers = []

            answers.append(form.cleaned_data['q1'])
            answers.append(form.cleaned_data['q2'])
            answers.append(form.cleaned_data['q3'])
            answers.append(form.cleaned_data['q4'])
            answers.append(form.cleaned_data['q5'])
            answers.append(form.cleaned_data['q6'])
            answers.append(form.cleaned_data['q7'])
            answers.append(form.cleaned_data['q8'])
            answers.append(form.cleaned_data['q9'])
            answers.append(form.cleaned_data['q10'])
            answers.append(form.cleaned_data['q11'])
            answers.append(form.cleaned_data['q12'])
            answers.append(form.cleaned_data['q13'])
            answers.append(form.cleaned_data['q14'])
            answers.append(form.cleaned_data['q15'])

            answers1 = " ".join(answers)

            form2 = Formulaire2()
    
            return render(request, 'formulaire/formulaire2.html', locals())


    # if a GET (or any other method) we'll create a blank form
    else:
        form = Formulaire1()

    return render(request, 'formulaire/formulaire1.html',{'form': form})


def formulaire2(request, answers1):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form2 = Formulaire2(request.POST)
        # check whether it's valid:
        if form2.is_valid():
            answers = []
            answers.append(form2.cleaned_data['q16'])
            answers.append(form2.cleaned_data['q17'])
            answers.append(form2.cleaned_data['q17'])
            answers.append(form2.cleaned_data['q19'])
            answers.append(form2.cleaned_data['q20'])
            answers.append(form2.cleaned_data['q21'])
            answers.append(form2.cleaned_data['q22'])
            answers.append(form2.cleaned_data['q23'])
            answers.append(form2.cleaned_data['q24'])
            answers.append(form2.cleaned_data['q25'])
            answers.append(form2.cleaned_data['q26'])
            answers.append(form2.cleaned_data['q27'])
            answers.append(form2.cleaned_data['q28'])
            answers.append(form2.cleaned_data['q29'])
            answers.append(form2.cleaned_data['q30'])

            answers2 = " ".join(answers)
            answers2 = answers1 + " " + answers2
        
            form3 = Formulaire3()

            return render(request, 'formulaire/formulaire3.html', locals())


    # if a GET (or any other method) we'll create a blank form
    else:
        form2 = Formulaire2()

    return render(request, 'formulaire/formulaire2.html', {'form':form2})

def formulaire3(request, answers2):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form3 = Formulaire3(request.POST)
        # check whether it's valid:
        if form3.is_valid():
            answers = []

            answers.append(form3.cleaned_data['q31'])
            answers.append(form3.cleaned_data['q32'])
            answers.append(form3.cleaned_data['q33'])
            answers.append(form3.cleaned_data['q34'])
            answers.append(form3.cleaned_data['q35'])
            answers.append(form3.cleaned_data['q36'])
            answers.append(form3.cleaned_data['q37'])
            answers.append(form3.cleaned_data['q38'])
            answers.append(form3.cleaned_data['q39'])
            answers.append(form3.cleaned_data['q40'])
            answers.append(form3.cleaned_data['q41'])

            answers3 = " ".join(answers)

            answers3 = answers2 + " " + answers3

            url = "/lao_model/?answers=" + answers3

            return redirect(to = url)


    # if a GET (or any other method) we'll create a blank form
    else:
        form3 = Formulaire3()

    return render(request, 'formulaire/formulaire3.html', {'form': form})

