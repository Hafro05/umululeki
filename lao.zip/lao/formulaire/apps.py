from django.apps import AppConfig


class FormulaireConfig(AppConfig):
    name = 'formulaire'
