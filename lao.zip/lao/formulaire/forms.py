from django import forms

my_choices = (
			("1", "Oui"),
			("0", "Non"),
		)

class Formulaire1(forms.Form):
    q1 = forms.ChoiceField(label='1. Passez-vous une grande partie de votre temps libre à apprendre de nouvelles choses?', choices = my_choices)
    q2 = forms.ChoiceField(label = '2. Êtes-vous intéressé en particulier par les techniques d’apprentissage  et d’enseignement ?' , choices = my_choices)
    q3 = forms.ChoiceField(label = '3. Aimez-vous  faire part aux autres de vos idées et partager vos connaissances ?' , choices = my_choices)
    q4 = forms.ChoiceField(label = '4. Êtes-vous à l’aise avec les chiffres ?' , choices = my_choices)
    q5 = forms.ChoiceField(label = '5. Il est facile pour vous de soutenir vos idées par un argumentaire cohérent ?' , choices = my_choices)
    q6 = forms.ChoiceField(label = '6. Vous reconnaissez vos torts et vos erreurs et en assumez les conséquences ?' , choices = my_choices)
    q7 = forms.ChoiceField(label = '7. Êtes-vous capable de travailler de manière autonome ?' , choices = my_choices)
    q8 = forms.ChoiceField(label = '8. Vous entretenez de bons rapport avec votre entourage ?' , choices = my_choices)
    q9 = forms.ChoiceField(label = '9. Êtes-vous capable de travailler continuellement pendant plusieurs heures ?' , choices = my_choices)
    q10 = forms.ChoiceField(label = '10. Il est facile pour vous de rester concentré sur ce que vous faites ?' , choices = my_choices)
    q11 = forms.ChoiceField(label = '11. Dans tout ce que vous faites vous essayez d’y ajouter une touche personnelle ?' , choices = my_choices)
    q12 = forms.ChoiceField(label = '12. Il est facile pour vous de nouer des relations avec les nouvelles personnes que vous rencontrez ?' , choices = my_choices)
    q13 = forms.ChoiceField(label = '13. Face aux personnes en difficulté vous faites preuve de compassion et leur venez en aide ?' , choices = my_choices)
    q14 = forms.ChoiceField(label = '14. Vous aimez écouter et apprendre des autres ?' , choices = my_choices)
    q15 = forms.ChoiceField(label = '15. Vous avez un esprit critique vis-a-vis de votre propre travail ?' , choices = my_choices)


class Formulaire2(forms.Form):
    q16 = forms.ChoiceField(label='16. Vous avez un esprit critique vis-a-vis du travail des autres ?', choices = my_choices)
    q17 = forms.ChoiceField(label = '17. Il est facile pour vous de trouver le lien existant entre les différents phénomènes qui se produisent autour de vous ?' , choices = my_choices)
    q18 = forms.ChoiceField(label = '18. Vous savez faire confiance aux autres et préférez travailler en équipe ?' , choices = my_choices)
    q19 = forms.ChoiceField(label = '19. Vous n’aimez pas le superflus et préférez vous résumer à l’essentiel ?' , choices = my_choices)
    q20 = forms.ChoiceField(label = '20. Vous savez garder votre sang froid et être patient ?' , choices = my_choices)
    q21 = forms.ChoiceField(label = '21. Il est facile pour vous de gérer le stress et de ne pas paniquer ?' , choices = my_choices)
    q22 = forms.ChoiceField(label = '22. Vous vous sentez plus à l’aise dans la nature qu’en milieu urbain ?' , choices = my_choices)
    q23 = forms.ChoiceField(label = '23. Vous aimez vous mettre au service des autres?' , choices = my_choices)
    q24= forms.ChoiceField(label = '24. Vous aimez être en charge de la gestion d’une équipe, d’un projet ?' , choices = my_choices)
    q25 = forms.ChoiceField(label = '25. Vous accordez une attention particulière au monde qui vous entoure ?' , choices = my_choices)
    q26 = forms.ChoiceField(label = '26. Vous êtes intéressez par la recherche et la découverte de choses nouvelles?' , choices = my_choices)
    q27 = forms.ChoiceField(label = '27. Dans un groupe de travail vous préférez être celui qui dirige ?' , choices = my_choices)
    q28 = forms.ChoiceField(label = '28. Dans votre raisonnement vous vous assurez toujours qu’il y ait de la logique ?' , choices = my_choices)
    q29 = forms.ChoiceField(label = '29. Vous préférez organiser et planifier vos travaux à l’avance ?' , choices = my_choices)
    q30 = forms.ChoiceField(label='30. Vous savez faire preuve de persévérance et vous ne vous découragez pas face aux difficultés ?', choices = my_choices)
    
class Formulaire3(forms.Form):
    q31 = forms.ChoiceField(label = '31. Il est facile pour vous de convaincre les autres de partager votre point de vue ?' , choices = my_choices)
    q32 = forms.ChoiceField(label = '32. Vous savez prendre des décisions dans l’urgence ?' , choices = my_choices)
    q33 = forms.ChoiceField(label = '33. Face à une situation vous savez prendre du recul et faire preuve d’objectivité ?' , choices = my_choices)
    q34 = forms.ChoiceField(label = '34. Il est facile pour vous de vous adapter à de nouvelles situations ?' , choices = my_choices)
    q35 = forms.ChoiceField(label = '35. Vous vous intéressez particulièrement aux arts et à la littérature ?' , choices = my_choices)
    q36 = forms.ChoiceField(label = '36. Il est facile pour vous de prendre la parole en public ?' , choices = my_choices)
    q37 = forms.ChoiceField(label = '37. Vous êtes intéressé par les nouveautés ?' , choices = my_choices)
    q38 = forms.ChoiceField(label = '38. Avez-vous une stabilité émotionnelle et psychologique ?' , choices = my_choices)
    q39 = forms.ChoiceField(label = '39. Vous avez un talent d’improvisation qui vous permet de vous en sortir lors des imprévus ?' , choices = my_choices)
    q40 = forms.ChoiceField(label = '40. Vous savez transcrire un jargon technique en explication compréhensible pour une personne non initiée au jargon ?' , choices = my_choices)
    q41 = forms.ChoiceField(label = '41. Vous restez efficace lorsque vous travaillez sous pression ?' , choices = my_choices)