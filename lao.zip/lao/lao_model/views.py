from django.shortcuts import render

from .apps import LaoModelConfig
import numpy as np

from django.http import JsonResponse
from rest_framework.views import APIView


#fonction pour transformer une entrée sous forme de chaine en vecteur
def vectorizer(str):
    a = []

    l = str.split(" ")
    
    for i in l:
        a.append(int(i))

    a = (np.array(a)).reshape(1, -1)
    
    return a

#fonction qui renvoie le domaine correspondant
def domaine(nbr):
	domaines = [
		"agriculture et environnement",
		"achitecture",
		"art, culture, design, mode",
		"banque, assurance, finance, comptabilité",
		"biologie",
		"commerce, management",
		"droit, sciences politiques",
		"enseignement",
		"histoire et sciences humaines",
		"hôtelerie, tourisme, restauration",
		"informatique",
		"ingénieur",
		"lettres et langues",
		"marketing et communication",
		"psychologie",
		"recherche",
		"santé",
		"sociologie"
	]

	return domaines[nbr]


class call_model(APIView):

	def get(self, request):
		if request.method == 'GET':
			#get answers from request
			answers = request.GET.get('answers')

			#transfor our answer from a string to a entry data for our model
			x = vectorizer(answers)

			#prediction
			prediction = LaoModelConfig.classifier.predict(x)

			url = "lao_model/lao_model" + str(prediction[0]) + ".html"

			return render(request, url, locals())

